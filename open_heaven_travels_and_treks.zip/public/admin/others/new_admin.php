<?php require_once('../../private/initialize.php'); ?>

<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="icon" type="image/png" sizes="96x96" href="<?php echo url_for('images/homepage_assets/icons/android-icon-192x192.png'); ?>">

  <title>Add Admin</title>

  <!-- Bootstrap core CSS -->
  <link href="<?php echo url_for('vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet'); ?>">

  <!-- Custom styles for this template -->
  <link href="<?php echo url_for('stylesheets/new_admin.css" rel="stylesheet" type="text/css'); ?>">
</head>

<body class="text-center body">
  <form class="form-signin" action="<?php echo url_for('/admin/admins.php') ?>" method="post">
    <img class="mb-4" src="<?php echo url_for('images/homepage_assets/icons/android-icon-192x192.png'); ?>" alt="" width="72"
      height="72">
    <h1 class="h3 mb-3 font-weight-normal">Add New Admin</h1>
    <label for="username" class="sr-only">Username</label>
    <input type="email" id="username" class="form-control" placeholder="Username" autofocus>
    <label for="password" class="sr-only">Password</label>
    <input type="password" id="password" class="form-control" placeholder="Password">
    <label for="confirmPassword" class="sr-only">Confirm Password</label>
    <input type="password" id="confirmPassword" class="form-control" placeholder="Confirm Password">
    <div class="checkbox mb-3">
      <label>
        <input type="checkbox" value="remember-me"> Remember me
      </label>
    </div>
    <button class="btn btn-lg btn-primary btn-block" type="submit">Add Admin</button>
    <p class="mt-5 mb-3 text-muted">&copy; 2018, Open Heaven Travel and Trecks</p>
  </form>
</body>

</html>