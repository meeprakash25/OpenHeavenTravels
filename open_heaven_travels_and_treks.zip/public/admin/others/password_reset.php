<?php require_once('../../private/initialize.php'); ?>
<?php 
  $errors = [];
  $username = '';
  $password = '';
  if(is_post_request()) {
    // $username = $_POST['username'] ?? '';
    // $password = $_POST['password'] ?? '';

    // $_SESSION['username'] = $_POST['username'];
    $_SESSION['info'] = "Password reset successful";

    redirect_to(url_for('/admin/login.php'));
  }
?>

<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="icon" type="image/png" sizes="96x96" href="<?php echo url_for('images/homepage_assets/icons/android-icon-192x192.png'); ?>">

  <title>Password Reset</title>

  <!-- Bootstrap core CSS -->
  <link href="<?php echo url_for('vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet'); ?>">

  <!-- Custom styles for this template -->
  <link href="<?php echo url_for('stylesheets/login.css" rel="stylesheet" type="text/css'); ?>">
</head>

<body class="text-center body">
  <form class="form-signin" action="<?php echo url_for('/admin/password_reset.php') ?>" method="post">
    <img class="mb-4" src="<?php echo url_for('images/homepage_assets/icons/android-icon-192x192.png'); ?>" alt="" width="72"
      height="72">
    <h1 class="h3 mb-3 font-weight-normal">Reset Your Password</h1>
    <div class="form-group">
      <input type="password" name="password" id="password" class="form-control" placeholder="New Password">
    </div>
    <div class="form-group">
      <input type="password" name="confirm_password" id="confirm-password" class="form-control" placeholder="Confirm Password">
    </div>
    <button class="btn btn-lg btn-primary btn-block" type="submit">Reset</button>
    <p class="mt-5 mb-3 text-muted">&copy; 2018, Open Heaven Travel and Trecks</p>
  </form>
</body>

</html>