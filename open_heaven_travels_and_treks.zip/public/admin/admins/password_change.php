<?php require_once('../../../private/initialize.php'); ?>

<?php
    global $errors;
    $current_password = '';
    $new_password = '';
    $confirm_password = '';
    if (!isset($_GET['id'])) {
        redirect_to(url_for('/admin/admins/index.php'));
    }
      $id = $_GET['id'];
      $current_admin = find_admin_by_id($id);
      if($current_admin['username'] != $_SESSION['user']){
        redirect_to(url_for('/admin/admins/index.php'));
      }
      if (is_post_request()) {
        $current_password = $_POST['current_password'] ?? '';
        $new_password = $_POST['new_password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        // validations
        if(is_blank($current_password)) {
          $errors[] = "Current password cannot be blank";
        }
        if(is_blank($new_password)) {
          $errors[] = "New password cannot be blank";
        }
        if(is_blank($confirm_password)) {
          $errors[] = "Confirm password cannot be blank";
        }
            // if there were no errors try update
        if(empty($errors)){
              if(password_verify($current_password, $current_admin['hashed_password'])){
                  // process form request
                  $admin = [];
                  $admin['id'] = $id;      
                  $admin['username'] = $current_admin['username'];
                  $admin['email'] = $current_admin['email'];
                  $admin['password'] = $_POST['new_password'] ?? '';
                  $admin['confirm_password'] = $_POST['confirm_password'] ?? '';

                  $result = update_admin($admin);
                  if ($result === true) {
                    $_SESSION['info'] = "Password changed successfully";
                    redirect_to(url_for('/admin/admins/index.php'));
                  } else {
                      // $errors = $result;
                      // var_dump($errors);
                      // reload the page with errors
                  }
              } else {
                //  password matches, username found but passwords dont match
                  $errors[] = "Password change failed";
                }
        }

  } else {
    // 
  }
  $admin_count = count_all_admins();
?>

  <?php $page_title = 'Change Password'; ?>

  <?php include(SHARED_PATH . '/admin_header.php') ?>

  <header id="main-header" class="py-4 bg-danger text-white">
    <div class="container">
      <div class="row">
        <div class="col-md-8">
          <h3>
            Change Password
          </h3>
        </div>
        <div class="col-md-4">
          <?php
              echo display_info(info());
            ?>
        </div>
      </div>
    </div>
  </header>

  <!-- ACTIONS -->
  <section id="action" class="py-4 mb-4 bg-light">
    <div class="container">
      <div class="row">
        <div class="col-md-3 pt-2 mr-auto">
          <a href="<?php echo url_for('/admin/index.php'); ?>" class="btn btn-light btn-block">
            <i class="fa fa-arrow-left"></i> Back To Dashboard
          </a>
        </div>
        <div class="col-md-3 pt-2">
          <a href="<?php echo url_for('/admin/admins/index.php'); ?>" class="btn btn-success btn-block">
            <i class="fa fa-arrow-left"></i> Go Back
          </a>
        </div>
        <div class="col-md-3 pt-2">
          <a href="<?php echo url_for('/admin/logout.php'); ?>" class="btn btn-danger btn-block">
            <i class="fa fa-user-times"></i> Logout
          </a>
        </div>
        <div class="col-md-3 pt-2">

        </div>
      </div>
    </div>
  </section>

  <!-- admins -->
  <!-- display errors -->
  <div class="container">
    <?php echo display_errors($errors); ?>
  </div>
  <div class="row m-0">
    <div class="col-md-12">
      <form class="form-signin" action="<?php echo url_for('/admin/admins/password_change.php?id=' . h(u($id))) ?>" method="post">

        <h1 class="h3 mb-3 font-weight-normal">Change Password</h1>
        <h4 class="mx-2"> User:
          <?php echo h($current_admin['username']); ?>
        </h4>

        <div class="form-group">
          <input type="password" name="current_password" id="current_password" class="form-control" placeholder="Current Password">
        </div>
        <div class="form-group">
          <input type="password" name="new_password" id="new_password" class="form-control" placeholder="New Password">
        </div>
        <div class="form-group">
          <input type="password" name="confirm_password" id="confirm-password" class="form-control" placeholder="Confirm Password">
        </div>
        <button class="btn btn-lg btn-primary btn-block" type="submit">Change</button>

      </form>
    </div>
  </div>

  <?php include(SHARED_PATH . '/admin_footer.php') ?>