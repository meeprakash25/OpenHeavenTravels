<?php require_once('../../private/initialize.php'); ?>

<?php require_login(); ?>

<?php $page_title = 'Admin Area | Dashboard'; ?>

<?php $tour_count = count_all_tours(); ?>
<?php $trek_count = count_all_treks(); ?>
<?php $testimonial_count = count_all_testimonials(); ?>
<?php $admin_count = count_all_admins(); ?>

<?php include(SHARED_PATH . '/admin_header.php') ?>

<header id="main-header" class="py-4 bg-primary text-white">
  <div class="container">
    <div class="row">
      <div class="col-md-8">
        <h3>
          <i class="fa fa-gears"></i> Dashboard</h3>
      </div>
      <div class="col-md-4">
        <?php
              echo display_info(info());
            ?>
      </div>
    </div>
  </div>
</header>

<!-- ACTIONS -->
<section id="action" class="py-2 mb-4 bg-light">
  <div class="container">
    <div class="row justify-content-between">
      <div class="col-md-3 pt-2">
        <a href="#" class="btn btn-primary btn-block" id="addTour" data-toggle="modal" data-target="#addTourModal">
          <i class="fa fa-plus"></i> Add Tour
        </a>
      </div>
      <div class="col-md-3 pt-2">
        <a href="#" class="btn btn-danger btn-block" id="addTrek" data-toggle="modal" data-target="#addTrekModal">
          <i class="fa fa-plus"></i> Add Trek
        </a>
      </div>
      <div class="col-md-3 pt-2">
        <a href="#" class="btn btn-success btn-block" id="addTestimonial" data-toggle="modal" data-target="#addTestimonialModal">
          <i class="fa fa-plus"></i> Add Testimonial
        </a>
      </div>

      <div class="col-md-3 pt-2">
        <a href="#" class="btn btn-warning btn-block text-light" id="addAdmin" data-toggle="modal" data-target="#addAdminModal">
          <i class="fa fa-plus"></i> Add Admin
        </a>
      </div>
    </div>
  </div>
</section>

<!-- Activities -->
<section id="posts">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header">
            <h4>Manage Content</h4>
          </div>
          <div class="card-body">
            <div class="row">
              <div class="col-lg-3 col-md-4 col-sm-6">
                <div class="card text-center bg-primary text-white mb-3 sr-icon">
                  <div class="card-body">
                    <h3>Tours</h3>
                    <h1 class="display-4">
                      <i class="fa fa-pencil"></i> <?php echo h($tour_count); ?>
                    </h1>
                    <a href="<?php echo url_for('/admin/tours/index.php'); ?>" class="btn btn-outline-light px-5">View</a>
                  </div>
                </div>
              </div>
              <div class="col-lg-3 col-md-4 col-sm-6">
                <div class="card text-center bg-danger text-white mb-3 sr-icon">
                  <div class="card-body">
                    <h3>Treks</h3>
                    <h1 class="display-4">
                      <i class="fa fa-pencil"></i> <?php echo h($trek_count); ?>
                    </h1>
                    <a href="<?php echo url_for('/admin/treks/index.php'); ?>" class="btn btn-outline-light px-5">View</a>
                  </div>
                </div>
              </div>
              <div class="col-lg-3 col-md-4 col-sm-6">
                <div class="card text-center bg-success text-white mb-3 sr-icon">
                  <div class="card-body">
                    <h3>Testimonials</h3>
                    <h1 class="display-4">
                      <i class="fa fa-pencil"></i> <?php echo h($testimonial_count); ?>
                    </h1>
                    <a href="<?php echo url_for('/admin/testimonials/index.php'); ?>" class="btn btn-outline-light px-5">View</a>
                  </div>
                </div>
              </div>
              <div class="col-lg-3 col-md-4 col-sm-6">
                <div class="card text-center bg-warning text-white mb-3 sr-icon">
                  <div class="card-body">
                    <h3>Admins</h3>
                    <h1 class="display-4">
                      <i class="fa fa-users"></i> <?php echo h($admin_count); ?>
                    </h1>
                    <a href="<?php echo url_for('/admin/admins/index.php'); ?>" class="btn btn-outline-light px-5">View</a>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ACTIONS -->
<section id="action" class="py-2 mb-4 bg-light">
  <div class="container">
    <div class="row justify-content-start">
      <div class="col-md-3 pt-2">
        <a href="#" class="btn btn-primary btn-block" id="editAbout" data-toggle="modal" data-target="#editAboutModal">
          <i class="fa fa-pencil"></i> Edit About Section
        </a>
      </div>
    </div>
  </div>
</section>

<div class="modals">
  <!-- include('<?php //echo url_for('/includes/newSubject.php'); ?>') -->
  <?php include(SHARED_PATH . '/modal_tour.php') ?>
  <?php include(SHARED_PATH . '/modal_trek.php') ?>
  <?php include(SHARED_PATH . '/modal_testimonial.php') ?>
  <?php include(SHARED_PATH . '/modal_about.php') ?>
  <?php include(SHARED_PATH . '/modal_admin.php') ?>
</div>

<!-- setting session values to null // values used for repopulating the form modal  -->
<?php include(SHARED_PATH . '/set_sessions_null.php') ?>

<?php include(SHARED_PATH . '/admin_footer.php') ?>