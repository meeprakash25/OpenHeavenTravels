<?php require_once('../../private/initialize.php'); ?>

<?php
  log_out_admin();
  redirect_to(url_for('/admin/login.php'));
?>

