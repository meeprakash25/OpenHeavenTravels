<?php 
  $local = "localhost";
  $web = "www.openheaventravels.com";
 define("DB_SERVER", $local);
  define("DB_USER", "openhjry_webuser");
  define("DB_PASS", "secretpassword");
  define("DB_NAME", "openhjry_openheaven");
?>