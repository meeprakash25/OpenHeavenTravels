<!-- setting session values to null // values used for repopulating the form modal  -->
<?php 
// tour
      $_SESSION['position'] = '';
      $_SESSION['icon'] = '';
      $_SESSION['destination'] = '';
      $_SESSION['tour_name'] = '';
      $_SESSION['activities'] = '';
      $_SESSION['tour_duration'] = '';
      $_SESSION['tour_grade'] = '';
      $_SESSION['seasons'] = '';
      $_SESSION['group_size'] = '';
      $_SESSION['altitude'] = '';
      $_SESSION['accomodation'] = '';
      $_SESSION['transport'] = '';
      $_SESSION['overview'] = '';
      $_SESSION['itinary'] = '';
      $_SESSION['cost_info'] = '';
      $_SESSION['gallery'] = '';
      $_SESSION['visible'] = '';
// treck
      $_SESSION['trek_name'] = '';
      $_SESSION['trek_type'] = '';
      $_SESSION['trip_duration'] = '';
      $_SESSION['trek_duration'] = '';
      $_SESSION['start_end_place'] = '';
      $_SESSION['trek_grade'] = '';
      $_SESSION['walking_hours'] = '';
      $_SESSION['highlights'] = '';
      $_SESSION['cost'] = '';
      $_SESSION['equiptments'] = '';

// testimonial
      $_SESSION['quote'] = '';
      $_SESSION['footer'] = '';

// about
      $_SESSION['head'] = '';
      $_SESSION['body'] = '';
      
// admin
      $_SESSION['username'] = '';
      $_SESSION['email'] = '';
      
?>