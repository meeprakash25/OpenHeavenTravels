<?php
// TOURS
  function fetch_about($options=[]) {
    global $db;
    $visible = $options['visible'] ?? false;
    $sql = "SELECT * FROM about ";
    if($visible){
      $sql .= "WHERE visible = true ";
    }
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    return $result;
  }
function validate_about($about) {
    global $errors;

    // head
    if(is_blank($about['head'])) {
      $errors[] = "Heading cannot be blank";
    } elseif(!has_length($about['head'], ['min' => 2, 'max' => 255])) {
      $errors[] = "Heading must be between 2 and 255 characters";
    }    

    // body
    if(is_blank($about['body'])) {
      $errors[] = "Body cannot be blank";
    }

    // visible
    // Make sure we are working with a string
    $visible_str = (string) $about['visible'];
    if(!has_inclusion_of($visible_str, ["0","1"])) {
      $errors[] = "Visible must be true or false";
    }
    return $errors;
  }

    function update_about($about) {
      global $db, $errors;

      $errors = validate_about($about);
      if(!empty($errors)) {
        return false;
      }

      $sql = "UPDATE about SET ";
      $sql .= "visible='" . db_escape($db, $about['visible']) . "',";
      $sql .= "head='" . db_escape($db, $about['head']) . "',";
      $sql .= "body='" . db_escape($db, $about['body']) . "' ";
      $sql .= "WHERE id='" . db_escape($db, 1) . "'";
      
      $result = mysqli_query($db, $sql);
      // For UPDATE statements, $result is true/false
      if($result) {
        return true;
      } else {
        // UPDATE failed
        echo mysqli_error($db);
        db_disconnect($db);
        exit;
      }

  }

// TOURS
  function find_all_tours($options=[]) {
    global $db;
    $visible = $options['visible'] ?? false;
    $sql = "SELECT * FROM tours ";
     if($visible){
      $sql .= "WHERE visible = true ";
    }
    $sql .= "ORDER BY position ASC";
    //echo $sql;
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    return $result;
  }

    function count_all_tours()
  {
      $tour_set = find_all_tours();
      $tour_count = mysqli_num_rows($tour_set);
      mysqli_free_result($tour_set);
      return $tour_count;
  }

  function find_tour_by_id($id, $options=[]) {
    global $db;
    $visible = $options['visible'] ?? false;
    $sql = "SELECT * FROM tours ";
    $sql .= "WHERE id='" . db_escape($db, $id) . "' ";
    if($visible){
      $sql .= "AND visible = true";
    }
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $tour = mysqli_fetch_assoc($result);
    mysqli_free_result($result);
    return $tour; // returns an assoc. array
  }

  function validate_tour($tour) {
    global $errors;

    // position
    if(is_blank($tour['position'])) {
      $errors[] = "Position cannot be blank";
    }

    // position
    if ($tour['position'] === 'Position'){
      $errors[] = "Please select a position";
    } else {
      // Make sure we are working with an integer
      $postion_int = (int) $tour['position'];
      if($postion_int <= 0) {
        $errors[] = "Position must be greater than zero.";
      }
      if($postion_int > 999) {
        $errors[] = "Position must be less than 999";
      }
    }

    // destination
    if(is_blank($tour['destination'])) {
      $errors[] = "Destination cannot be blank";
    } elseif(!has_length($tour['destination'], ['min' => 2, 'max' => 255])) {
      $errors[] = "Destination must be between 2 and 255 characters";
    }
    // activity_name
    if(is_blank($tour['tour_name'])) {
      $errors[] = "Name of Tour cannot be blank";
    } elseif(!has_length($tour['tour_name'], ['min' => 2, 'max' => 255])) {
      $errors[] = "Name of Tour must be between 2 and 255 characters";
    }
    // $current_id = $tour['id'] ?? '0';
    // if(!has_unique_tour_menu_name($tour['destination'], $current_id)) {
    //   $errors[] = "Destination must be unique.";
    // }

    // activities
    if(is_blank($tour['activities'])) {
      $errors[] = "Activities cannot be blank";
    } elseif(!has_length($tour['activities'], ['min' => 2, 'max' => 255])) {
      $errors[] = "Activities must be between 2 and 255 characters";
    }

    
    // tour_duration
    if(is_blank($tour['tour_duration'])) {
      $errors[] = "Tour Duration cannot be blank";
    } elseif(!has_length($tour['tour_duration'], ['min' => 2, 'max' => 255])) {
      $errors[] = "Tour Duration must be between 2 and 255 characters";
    }
    
    // tour_duration
    if(is_blank($tour['tour_grade'])) {
      $errors[] = "Tour Grade cannot be blank";
    } elseif(!has_length($tour['tour_grade'], ['min' => 2, 'max' => 255])) {
      $errors[] = "Tour Grade must be between 2 and 255 characters";
    }

    
    // Seasons
    if(is_blank($tour['seasons'])) {
      $errors[] = "Seasons cannot be blank";
    } elseif(!has_length($tour['seasons'], ['min' => 2, 'max' => 255])) {
      $errors[] = "Seasons must be between 2 and 255 characters";
    }


    // group_size
    if(is_blank($tour['group_size'])) {
      $errors[] = "Group Size cannot be blank";
    } elseif(!has_length($tour['group_size'], ['min' => 2, 'max' => 255])) {
      $errors[] = "Group Size must be between 2 and 255 characters";
    }


    // altitude
    if(is_blank($tour['altitude'])) {
      $errors[] = "Altitude cannot be blank";
    } elseif(!has_length($tour['altitude'], ['min' => 2, 'max' => 255])) {
      $errors[] = "Altitude must be between 2 and 255 characters";
    }


    // accomodation
    if(is_blank($tour['accomodation'])) {
      $errors[] = "Accomodation cannot be blank";
    } elseif(!has_length($tour['accomodation'], ['min' => 2, 'max' => 255])) {
      $errors[] = "Accomodation must be between 2 and 255 characters";
    }


    // transport
    if(is_blank($tour['transport'])) {
      $errors[] = "Transport cannot be blank";
    } elseif(!has_length($tour['transport'], ['min' => 2, 'max' => 255])) {
      $errors[] = "Transport must be between 2 and 255 characters";
    }

    // overview
    if(is_blank($tour['overview'])) {
      $errors[] = "Overview cannot be blank";
    }

    // itinary
    if(is_blank($tour['itinary'])) {
      $errors[] = "Itinary cannot be blank";
    }

    // cost_info
    if(is_blank($tour['cost_info'])) {
      $errors[] = "Cost Info cannot be blank";
    }

    // gallery
    // if(is_blank($tour['gallery'])) {
    //   $errors[] = "gallery cannot be blank";
    // }


    // visible
    // Make sure we are working with a string
    $visible_str = (string) $tour['visible'];
    if(!has_inclusion_of($visible_str, ["0","1"])) {
      $errors[] = "Visible must be true or false";
    }
    return $errors;
  }

  function insert_tour($tour) {
    global $db, $errors;

    $errors = validate_tour($tour);
    if(!empty($errors)) {
      return false;
    }

    shift_tour_positions(0, $tour['position']);

    $sql = "INSERT INTO tours ";
    $sql .= "(position, visible, destination, tour_name, activities, tour_duration, tour_grade, seasons, group_size, altitude, accomodation, transport, overview, itinary, cost_info, gallery) ";
    $sql .= "VALUES (";
    $sql .= "'" . db_escape($db, $tour['position']) . "',";
    $sql .= "'" . db_escape($db, $tour['visible']) . "',";
    $sql .= "'" . db_escape($db, $tour['destination']) . "',";
    $sql .= "'" . db_escape($db, $tour['tour_name']) . "',";
    $sql .= "'" . db_escape($db, $tour['activities']) . "',";
    $sql .= "'" . db_escape($db, $tour['tour_duration']) . "',";
    $sql .= "'" . db_escape($db, $tour['tour_grade']) . "',";
    $sql .= "'" . db_escape($db, $tour['seasons']) . "',";
    $sql .= "'" . db_escape($db, $tour['group_size']) . "',";
    $sql .= "'" . db_escape($db, $tour['altitude']) . "',";
    $sql .= "'" . db_escape($db, $tour['accomodation']) . "',";
    $sql .= "'" . db_escape($db, $tour['transport']) . "',";
    $sql .= "'" . db_escape($db, $tour['overview']) . "',";
    $sql .= "'" . db_escape($db, $tour['itinary']) . "',";
    $sql .= "'" . db_escape($db, $tour['cost_info']) . "',";
    $sql .= "'" . db_escape($db, $tour['gallery']) . "'";
    $sql .= ")";
    $result = mysqli_query($db, $sql);
    // For INSERT statements, $result is true/false
    if($result) {
      return true;
    } else {
      // INSERT failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }

  function update_tour($tour) {
  global $db, $errors;

    $errors = validate_tour($tour);
    if(!empty($errors)) {
      return false;
    }

    $old_tour = find_tour_by_id($tour['id']);
    $old_position = $old_tour['position'];
    shift_tour_positions($old_position, $tour['position'], $tour['id']);

    $sql = "UPDATE tours SET ";
    $sql .= "position='" . db_escape($db, $tour['position']) . "',";
    $sql .= "visible='" . db_escape($db, $tour['visible']) . "',";
    $sql .= "destination='" . db_escape($db, $tour['destination']) . "',";
    $sql .= "tour_name='" . db_escape($db, $tour['tour_name']) . "',";
    $sql .= "activities='" . db_escape($db, $tour['activities']) . "',";
    $sql .= "tour_duration='" . db_escape($db, $tour['tour_duration']) . "',";
    $sql .= "tour_grade='" . db_escape($db, $tour['tour_grade']) . "',";
    $sql .= "seasons='" . db_escape($db, $tour['seasons']) . "',";
    $sql .= "group_size='" . db_escape($db, $tour['group_size']) . "',";
    $sql .= "altitude='" . db_escape($db, $tour['altitude']) . "',";
    $sql .= "accomodation='" . db_escape($db, $tour['accomodation']) . "',";
    $sql .= "transport='" . db_escape($db, $tour['transport']) . "',";
    $sql .= "overview='" . db_escape($db, $tour['overview']) . "',";
    $sql .= "itinary='" . db_escape($db, $tour['itinary']) . "',";
    $sql .= "cost_info='" . db_escape($db, $tour['cost_info']) . "',";
    $sql .= "gallery='" . db_escape($db, $tour['gallery']) . "' ";
    $sql .= "WHERE id='" . db_escape($db, $tour['id']) . "' ";
    $sql .= "LIMIT 1";
    
    $result = mysqli_query($db, $sql);
    // For UPDATE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // UPDATE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }

  }

  function delete_tour($id) {
    global $db;

        $old_tour = find_tour_by_id($id);
    $old_position = $old_tour['position'];
    shift_tour_positions($old_position, 0, $id);

    $sql = "DELETE FROM tours ";
    $sql .= "WHERE id='" . db_escape($db, $id) . "' ";
    $sql .= "LIMIT 1";
    $result = mysqli_query($db, $sql);

    // For DELETE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // DELETE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }

    function shift_tour_positions($start_pos, $end_pos, $current_id=0) {
    global $db;

    if($start_pos == $end_pos) { return; }

    $sql = "UPDATE tours ";
    if($start_pos == 0) {
      // new item, +1 to items greater than $end_pos
      $sql .= "SET position = position + 1 ";
      $sql .= "WHERE position >= '" . db_escape($db, $end_pos) . "' ";
    } elseif($end_pos == 0) {
      // delete item, -1 from items greater than $start_pos
      $sql .= "SET position = position - 1 ";
      $sql .= "WHERE position > '" . db_escape($db, $start_pos) . "' ";
    } elseif($start_pos < $end_pos) {
      // move later, -1 from items between (including $end_pos)
      $sql .= "SET position = position - 1 ";
      $sql .= "WHERE position > '" . db_escape($db, $start_pos) . "' ";
      $sql .= "AND position <= '" . db_escape($db, $end_pos) . "' ";
    } elseif($start_pos > $end_pos) {
      // move earlier, +1 to items between (including $end_pos)
      $sql .= "SET position = position + 1 ";
      $sql .= "WHERE position >= '" . db_escape($db, $end_pos) . "' ";
      $sql .= "AND position < '" . db_escape($db, $start_pos) . "' ";
    }
    // Exclude the current_id in the SQL WHERE clause
    $sql .= "AND id != '" . db_escape($db, $current_id) . "' ";

    $result = mysqli_query($db, $sql);
    // For UPDATE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // UPDATE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }


  // TREKS

function find_all_treks($options=[]) {
    global $db;
    $visible = $options['visible'] ?? false;
    $sql = "SELECT * FROM treks ";
    if($visible){
      $sql .= "WHERE visible = true ";
    }
    $sql .= "ORDER BY position ASC";
    //echo $sql;
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    return $result;
  }

    function count_all_treks()
  {
      $trek_set = find_all_treks();
      $trek_count = mysqli_num_rows($trek_set);
      mysqli_free_result($trek_set);
      return $trek_count;
  }

  function find_trek_by_id($id, $options=[]) {
    global $db;
    $visible = $options['visible'] ?? false;
    $sql = "SELECT * FROM treks ";
    $sql .= "WHERE id='" . db_escape($db, $id) . "' ";
    if($visible){
      $sql .= "AND visible = true";
    }
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $trek = mysqli_fetch_assoc($result);
    mysqli_free_result($result);
    return $trek; // returns an assoc. array
  }

  function validate_trek($trek) {
    global $errors;

    // position
    if(is_blank($trek['position'])) {
      $errors[] = "Position cannot be blank";
    }

    // position
    if ($trek['position'] === 'Position'){
      $errors[] = "Please select a position";
    } else {
      // Make sure we are working with an integer
      $postion_int = (int) $trek['position'];
      if($postion_int <= 0) {
        $errors[] = "Position must be greater than zero.";
      }
      if($postion_int > 999) {
        $errors[] = "Position must be less than 999";
      }
    }

    // start_end_place)
    if(is_blank($trek['start_end_place'])) {
      $errors[] = "Start End Place cannot be blank";
    } elseif(!has_length($trek['start_end_place'], ['min' => 2, 'max' => 255])) {
      $errors[] = "Start End Place must be between 2 and 255 characters";
    }
    // activity_name
    if(is_blank($trek['trek_name'])) {
      $errors[] = "Name of trek cannot be blank";
    } elseif(!has_length($trek['trek_name'], ['min' => 2, 'max' => 255])) {
      $errors[] = "Name of trek must be between 2 and 255 characters";
    }
    // $current_id = $trek['id'] ?? '0';
    // if(!has_unique_trek_menu_name($trek['destination'], $current_id)) {
    //   $errors[] = "Destination must be unique.";
    // }

    // trek_type
    if(is_blank($trek['trek_type'])) {
      $errors[] = "Trek Type cannot be blank";
    } elseif(!has_length($trek['trek_type'], ['min' => 2, 'max' => 255])) {
      $errors[] = "Trek Type must be between 2 and 255 characters";
    }

    
    // trip_duration
    if(is_blank($trek['trip_duration'])) {
      $errors[] = "Trip Duration cannot be blank";
    } elseif(!has_length($trek['trip_duration'], ['min' => 2, 'max' => 255])) {
      $errors[] = "Trip Duration must be between 2 and 255 characters";
    }
    // trek_duration
    if(is_blank($trek['trek_duration'])) {
      $errors[] = "Trek Duration cannot be blank";
    } elseif(!has_length($trek['trek_duration'], ['min' => 2, 'max' => 255])) {
      $errors[] = "Trek Duration must be between 2 and 255 characters";
    }
    
    // trek_grade
    if(is_blank($trek['trek_grade'])) {
      $errors[] = "Trek Grade cannot be blank";
    } elseif(!has_length($trek['trek_grade'], ['min' => 2, 'max' => 255])) {
      $errors[] = "Trek Grade must be between 2 and 255 characters";
    }

    
    // Seasons
    if(is_blank($trek['seasons'])) {
      $errors[] = "Seasons cannot be blank";
    } elseif(!has_length($trek['seasons'], ['min' => 2, 'max' => 255])) {
      $errors[] = "Seasons must be between 2 and 255 characters";
    }


    // group_size
    if(is_blank($trek['group_size'])) {
      $errors[] = "Group Size cannot be blank";
    } elseif(!has_length($trek['group_size'], ['min' => 1, 'max' => 255])) {
      $errors[] = "Group Size must be between 2 and 255 characters";
    }


    // altitude
    if(is_blank($trek['altitude'])) {
      $errors[] = "Altitude cannot be blank";
    } elseif(!has_length($trek['altitude'], ['min' => 2, 'max' => 255])) {
      $errors[] = "Altitude must be between 2 and 255 characters";
    }


    // highlights
    if(is_blank($trek['highlights'])) {
      $errors[] = "Highlights cannot be blank";
    }


    // walking_hours
    if(is_blank($trek['walking_hours'])) {
      $errors[] = "Walking Hours cannot be blank";
    } elseif(!has_length($trek['walking_hours'], ['min' => 2, 'max' => 255])) {
      $errors[] = "Walking Hours must be between 2 and 255 characters";
    }
    
    // cost
    if(is_blank($trek['cost'])) {
      $errors[] = "Cost cannot be blank";
    } elseif(!has_length($trek['cost'], ['min' => 2, 'max' => 255])) {
      $errors[] = "Cost must be between 2 and 255 characters";
    }

    // overview
    if(is_blank($trek['overview'])) {
      $errors[] = "Overview cannot be blank";
    }

    // itinary
    if(is_blank($trek['itinary'])) {
      $errors[] = "Itinary cannot be blank";
    }

    // equiptments
    if(is_blank($trek['equiptments'])) {
      $errors[] = "Equiptments cannot be blank";
    }
    // cost_info
    if(is_blank($trek['cost_info'])) {
      $errors[] = "Cost Info cannot be blank";
    }

    // gallery
    // if(is_blank($trek['gallery'])) {
    //   $errors[] = "gallery cannot be blank";
    // }


    // visible
    // Make sure we are working with a string
    $visible_str = (string) $trek['visible'];
    if(!has_inclusion_of($visible_str, ["0","1"])) {
      $errors[] = "Visible must be true or false";
    }
    return $errors;
  }

  function insert_trek($trek) {
    global $db, $errors;

    $errors = validate_trek($trek);
    if(!empty($errors)) {
      return false;
    }

    shift_trek_positions(0, $trek['position']);

    $sql = "INSERT INTO treks ";
    $sql .= "(position, visible, trip_duration, trek_duration, start_end_place, trek_name, trek_type, trek_grade, seasons, group_size, altitude, highlights, walking_hours, cost, overview, itinary, cost_info, equiptments, gallery) ";
    $sql .= "VALUES (";
    $sql .= "'" . db_escape($db, $trek['position']) . "',";
    $sql .= "'" . db_escape($db, $trek['visible']) . "',";
    $sql .= "'" . db_escape($db, $trek['trip_duration']) . "',";
    $sql .= "'" . db_escape($db, $trek['trek_duration']) . "',";
    $sql .= "'" . db_escape($db, $trek['start_end_place']) . "',";
    $sql .= "'" . db_escape($db, $trek['trek_name']) . "',";
    $sql .= "'" . db_escape($db, $trek['trek_type']) . "',";
    $sql .= "'" . db_escape($db, $trek['trek_grade']) . "',";
    $sql .= "'" . db_escape($db, $trek['seasons']) . "',";
    $sql .= "'" . db_escape($db, $trek['group_size']) . "',";
    $sql .= "'" . db_escape($db, $trek['altitude']) . "',";
    $sql .= "'" . db_escape($db, $trek['highlights']) . "',";
    $sql .= "'" . db_escape($db, $trek['walking_hours']) . "',";
    $sql .= "'" . db_escape($db, $trek['cost']) . "',";
    $sql .= "'" . db_escape($db, $trek['overview']) . "',";
    $sql .= "'" . db_escape($db, $trek['itinary']) . "',";
    $sql .= "'" . db_escape($db, $trek['cost_info']) . "',";
    $sql .= "'" . db_escape($db, $trek['equiptments']) . "',";
    $sql .= "'" . db_escape($db, $trek['gallery']) . "'";
    $sql .= ")";
    $result = mysqli_query($db, $sql);
    // For INSERT statements, $result is true/false
    if($result) {
      return true;
    } else {
      // INSERT failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }

  function update_trek($trek) {
  global $db, $errors;

    $errors = validate_trek($trek);
    if(!empty($errors)) {
      return false;
    }

    $old_trek = find_trek_by_id($trek['id']);
    $old_position = $old_trek['position'];
    shift_trek_positions($old_position, $trek['position'], $trek['id']);

    $sql = "UPDATE treks SET ";
    $sql .= "position='" . db_escape($db, $trek['position']) . "',";
    $sql .= "visible='" . db_escape($db, $trek['visible']) . "',";
    $sql .= "trip_duration='" . db_escape($db, $trek['trip_duration']) . "',";
    $sql .= "trek_duration='" . db_escape($db, $trek['trek_duration']) . "',";
    $sql .= "start_end_place='" . db_escape($db, $trek['start_end_place']) . "',";
    $sql .= "trek_name='" . db_escape($db, $trek['trek_name']) . "',";
    $sql .= "trek_type='" . db_escape($db, $trek['trek_type']) . "',";
    $sql .= "trek_grade='" . db_escape($db, $trek['trek_grade']) . "',";
    $sql .= "seasons='" . db_escape($db, $trek['seasons']) . "',";
    $sql .= "group_size='" . db_escape($db, $trek['group_size']) . "',";
    $sql .= "altitude='" . db_escape($db, $trek['altitude']) . "',";
    $sql .= "highlights='" . db_escape($db, $trek['highlights']) . "',";
    $sql .= "walking_hours='" . db_escape($db, $trek['walking_hours']) . "',";
    $sql .= "cost='" . db_escape($db, $trek['cost']) . "',";
    $sql .= "overview='" . db_escape($db, $trek['overview']) . "',";
    $sql .= "itinary='" . db_escape($db, $trek['itinary']) . "',";
    $sql .= "cost_info='" . db_escape($db, $trek['cost_info']) . "',";
    $sql .= "equiptments='" . db_escape($db, $trek['equiptments']) . "',";
    $sql .= "gallery='" . db_escape($db, $trek['gallery']) . "' ";
    $sql .= "WHERE id='" . db_escape($db, $trek['id']) . "' ";
    $sql .= "LIMIT 1";
    $result = mysqli_query($db, $sql);
    // For UPDATE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // UPDATE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }

  }

  function delete_trek($id) {
    global $db;

    $old_trek = find_trek_by_id($id);
    $old_position = $old_trek['position'];
    shift_trek_positions($old_position, 0, $id);

    $sql = "DELETE FROM treks ";
    $sql .= "WHERE id='" . db_escape($db, $id) . "' ";
    $sql .= "LIMIT 1";
    $result = mysqli_query($db, $sql);

    // For DELETE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // DELETE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }

    function shift_trek_positions($start_pos, $end_pos, $current_id=0) {
    global $db;

    if($start_pos == $end_pos) { return; }

    $sql = "UPDATE treks ";
    if($start_pos == 0) {
      // new item, +1 to items greater than $end_pos
      $sql .= "SET position = position + 1 ";
      $sql .= "WHERE position >= '" . db_escape($db, $end_pos) . "' ";
    } elseif($end_pos == 0) {
      // delete item, -1 from items greater than $start_pos
      $sql .= "SET position = position - 1 ";
      $sql .= "WHERE position > '" . db_escape($db, $start_pos) . "' ";
    } elseif($start_pos < $end_pos) {
      // move later, -1 from items between (including $end_pos)
      $sql .= "SET position = position - 1 ";
      $sql .= "WHERE position > '" . db_escape($db, $start_pos) . "' ";
      $sql .= "AND position <= '" . db_escape($db, $end_pos) . "' ";
    } elseif($start_pos > $end_pos) {
      // move earlier, +1 to items between (including $end_pos)
      $sql .= "SET position = position + 1 ";
      $sql .= "WHERE position >= '" . db_escape($db, $end_pos) . "' ";
      $sql .= "AND position < '" . db_escape($db, $start_pos) . "' ";
    }
    // Exclude the current_id in the SQL WHERE clause
    $sql .= "AND id != '" . db_escape($db, $current_id) . "' ";

    $result = mysqli_query($db, $sql);
    // For UPDATE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // UPDATE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }



// TESTIMONIALS

function find_all_testimonials($options=[]) {
    global $db;
    $visible = $options['visible'] ?? false;
    $sql = "SELECT * FROM testimonials ";
    if($visible){
      $sql .= "WHERE visible = true ";
    }
    $sql .= "ORDER BY position ASC";
    //echo $sql;
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    return $result;
  }

  function count_all_testimonials()  {
      $testimonial_set = find_all_testimonials();
      $testimonial_count = mysqli_num_rows($testimonial_set);
      mysqli_free_result($testimonial_set);
      return $testimonial_count;
  }

  function find_testimonial_by_id($id) {
    global $db;

    $sql = "SELECT * FROM testimonials ";
    $sql .= "WHERE id='" . db_escape($db, $id) . "'";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $testimonial = mysqli_fetch_assoc($result);
    mysqli_free_result($result);
    return $testimonial; // returns an assoc. array
  }

  function validate_testimonial($testimonial) {
    global $errors;

    // position
    if(is_blank($testimonial['position'])) {
      $errors[] = "Position cannot be blank";
    }

    // position
    if ($testimonial['position'] === 'Position'){
      $errors[] = "Please select a position";
    } else {
      // Make sure we are working with an integer
      $postion_int = (int) $testimonial['position'];
      if($postion_int <= 0) {
        $errors[] = "Position must be greater than zero.";
      }
      if($postion_int > 999) {
        $errors[] = "Position must be less than 999";
      }
    }


    // quote
    if(is_blank($testimonial['quote'])) {
      $errors[] = "Quote cannot be blank";
    }
    // activity_name
    if(is_blank($testimonial['footer'])) {
      $errors[] = "Name cannot be blank";
    } elseif(!has_length($testimonial['footer'], ['min' => 2, 'max' => 255])) {
      $errors[] = "Name must be between 2 and 255 characters";
    }
    
    // visible
    // Make sure we are working with a string
    $visible_str = (string) $testimonial['visible'];
    if(!has_inclusion_of($visible_str, ["0","1"])) {
      $errors[] = "Visible must be true or false";
    }
    return $errors;
  }

  function insert_testimonial($testimonial) {
    global $db, $errors;

    $errors = validate_testimonial($testimonial);
    if(!empty($errors)) {
      return false;
    }

    shift_testimonial_positions(0, $testimonial['position']);

    $sql = "INSERT INTO testimonials ";
    $sql .= "(position, visible, quote, footer) ";
    $sql .= "VALUES (";
    $sql .= "'" . db_escape($db, $testimonial['position']) . "',";
    $sql .= "'" . db_escape($db, $testimonial['visible']) . "',";
    $sql .= "'" . db_escape($db, $testimonial['quote']) . "',";
    $sql .= "'" . db_escape($db, $testimonial['footer']) . "'";
    $sql .= ")";
    $result = mysqli_query($db, $sql);
    // For INSERT statements, $result is true/false
    if($result) {
      return true;
    } else {
      // INSERT failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }

  function update_testimonial($testimonial) {
  global $db, $errors;

    $errors = validate_testimonial($testimonial);
    if(!empty($errors)) {
      return false;
    }

    $old_testimonial = find_testimonial_by_id($testimonial['id']);
    $old_position = $old_testimonial['position'];
    shift_testimonial_positions($old_position, $testimonial['position'], $testimonial['id']);


    $sql = "UPDATE testimonials SET ";
    $sql .= "position='" . db_escape($db, $testimonial['position']) . "',";
    $sql .= "visible='" . db_escape($db, $testimonial['visible']) . "',";
    $sql .= "quote='" . db_escape($db, $testimonial['quote']) . "',";
    $sql .= "footer='" . db_escape($db, $testimonial['footer']) . "' ";
    $sql .= "WHERE id='" . db_escape($db, $testimonial['id']) . "' ";
    $sql .= "LIMIT 1";
    
    $result = mysqli_query($db, $sql);
    // For UPDATE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // UPDATE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }

  }

  function delete_testimonial($id) {
    global $db;

    $old_testimonial = find_testimonial_by_id($id);
    $old_position = $old_testimonial['position'];
    shift_testimonial_positions($old_position, 0, $id);

    $sql = "DELETE FROM testimonials ";
    $sql .= "WHERE id='" . db_escape($db, $id) . "' ";
    $sql .= "LIMIT 1";
    $result = mysqli_query($db, $sql);

    // For DELETE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // DELETE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }

    function shift_testimonial_positions($start_pos, $end_pos, $current_id=0) {
    global $db;

    if($start_pos == $end_pos) { return; }

    $sql = "UPDATE testimonials ";
    if($start_pos == 0) {
      // new item, +1 to items greater than $end_pos
      $sql .= "SET position = position + 1 ";
      $sql .= "WHERE position >= '" . db_escape($db, $end_pos) . "' ";
    } elseif($end_pos == 0) {
      // delete item, -1 from items greater than $start_pos
      $sql .= "SET position = position - 1 ";
      $sql .= "WHERE position > '" . db_escape($db, $start_pos) . "' ";
    } elseif($start_pos < $end_pos) {
      // move later, -1 from items between (including $end_pos)
      $sql .= "SET position = position - 1 ";
      $sql .= "WHERE position > '" . db_escape($db, $start_pos) . "' ";
      $sql .= "AND position <= '" . db_escape($db, $end_pos) . "' ";
    } elseif($start_pos > $end_pos) {
      // move earlier, +1 to items between (including $end_pos)
      $sql .= "SET position = position + 1 ";
      $sql .= "WHERE position >= '" . db_escape($db, $end_pos) . "' ";
      $sql .= "AND position < '" . db_escape($db, $start_pos) . "' ";
    }
    // Exclude the current_id in the SQL WHERE clause
    $sql .= "AND id != '" . db_escape($db, $current_id) . "' ";

    $result = mysqli_query($db, $sql);
    // For UPDATE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // UPDATE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }



// ADMINS

function find_all_admins() {
    global $db;

    $sql = "SELECT * FROM admins ";
    $sql .= "ORDER BY timestamp ASC";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    return $result;
  }

    function count_all_admins()  {
      $admin_set = find_all_admins();
      $admin_count = mysqli_num_rows($admin_set);
      mysqli_free_result($admin_set);
      return $admin_count;
  }

  function find_admin_by_id($id) {
    global $db;

    $sql = "SELECT * FROM admins ";
    $sql .= "WHERE id='" . db_escape($db, $id) . "'";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $admin = mysqli_fetch_assoc($result);
    mysqli_free_result($result);
    return $admin; // returns an assoc. array
  }
  function find_admin_by_username($username) {
    global $db;

    $sql = "SELECT * FROM admins ";
    $sql .= "WHERE username='" . db_escape($db, $username) . "'";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $admin = mysqli_fetch_assoc($result);
    mysqli_free_result($result);
    return $admin; // returns an assoc. array
  }

  function validate_admin($admin, $options=[]) {
    global $errors;
    $password_required = $options['password_required'] ?? true;
    // username
    if(is_blank($admin['username'])) {
      $errors[] = "Username cannot be blank";
    } elseif(!has_length($admin['username'], ['min' => 2, 'max' => 255])) {
      $errors[] = "Username too short";
    } elseif (!has_unique_username($admin['username'], $admin['id'])) {
      $errors[] = "Username already exists";
    }
    // email
    if(is_blank($admin['email'])) {
      $errors[] = "Email cannot be blank";
    } elseif (!has_valid_email_format($admin['email'])) {
      $errors[] = "Email not valid";
    } elseif(!has_length($admin['email'], ['min' => 7, 'max' => 255])) {
      $errors[] = "Email must be at least 7 characters";
    }
    if($password_required) {
      if(is_blank($admin['password'])) {
        $errors[] = "Password cannot be blank";
      } 
      elseif (!has_length($admin['password'], array('min' => 6))) {
        $errors[] = "Password must contain at least 6 characters";
      } 
      elseif (!preg_match('/[A-Z]/', $admin['password'])) {
        $errors[] = "Password must contain at least 1 uppercase letter";
      }
      elseif (!preg_match('/[a-z]/', $admin['password'])) {
        $errors[] = "Password must contain at least 1 lowercase letter";
      } 
      // elseif (!preg_match('/[0-9]/', $admin['password'])) {
      //   $errors[] = "Password must contain at least 1 number";
      // } 
      // elseif (!preg_match('/[^A-Za-z0-9\s]/', $admin['password'])) {
      //   $errors[] = "Password must contain at least 1 symbol";
      // }

      if(is_blank($admin['confirm_password'])) {
        $errors[] = "Confirm password cannot be blank";
      } elseif ($admin['password'] !== $admin['confirm_password']) {
        $errors[] = "Passwords don't match";
      }
    }
    return $errors;
  }

  function insert_admin($admin) {
    global $db, $errors;

    $errors = validate_admin($admin);
    if(!empty($errors)) {
      return false;
    }

    $hashed_password = password_hash($admin['password'], PASSWORD_BCRYPT);

    $sql = "INSERT INTO admins ";
    $sql .= "(username, email, hashed_password) ";
    $sql .= "VALUES (";
    $sql .= "'" . db_escape($db, $admin['username']) . "',";
    $sql .= "'" . db_escape($db, $admin['email']) . "',";
    $sql .= "'" . db_escape($db, $hashed_password) . "'";
    $sql .= ")";
    $result = mysqli_query($db, $sql);
    // For INSERT statements, $result is true/false
    if($result) {
      return true;
    } else {
      // INSERT failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }

  function update_admin($admin) {
  global $db, $errors;

  $password_sent = !is_blank($admin['password']);

    $errors = validate_admin($admin, ['password_required' => $password_sent]);
    if(!empty($errors)) {
      return false;
    }
    
    $hashed_password = password_hash($admin['password'], PASSWORD_BCRYPT);
    $sql = "UPDATE admins SET ";
    $sql .= "username='" . db_escape($db, $admin['username']) . "',";
    if($password_sent) {
      $sql .= "hashed_password='" . db_escape($db, $hashed_password) . "',";
    }
    $sql .= "email='" . db_escape($db, $admin['email']) . "' ";
    $sql .= "WHERE id='" . db_escape($db, $admin['id']) . "' ";
    $sql .= "LIMIT 1";
    
    $result = mysqli_query($db, $sql);
    // For UPDATE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // UPDATE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }

  }

  function delete_admin($id) {
    global $db;

    $sql = "DELETE FROM admins ";
    $sql .= "WHERE id='" . db_escape($db, $id) . "' ";
    $sql .= "LIMIT 1";
    $result = mysqli_query($db, $sql);

    // For DELETE statements, $result is true/false
    if($result) {
      return true;
    } else {
      // DELETE failed
      echo mysqli_error($db);
      db_disconnect($db);
      exit;
    }
  }




 ?>